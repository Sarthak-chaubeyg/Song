"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { songs } from "@/lib/songs"
import Link from "next/link"

const genres = ["Pop", "Hip-Hop", "Rock", "Latin", "Dance", "Electronic", "R&B", "Indie", "Classical", "Metal"]

// This is the search page of the Spotify clone
// It allows users to search for songs and browse genres
export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredSongs = songs.filter(
    (song) =>
      song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      song.artist.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredGenres = genres.filter((genre) => genre.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Search</h1>
      <div className="relative mb-6">
        <input
          type="text"
          placeholder="What do you want to listen to?"
          className="w-full p-3 pl-10 bg-gray-800 rounded-full text-white focus:outline-none focus:ring-2 focus:ring-white"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>
      {searchTerm && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Search Results</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSongs.map((song) => (
              <Link href={`/song/${song.id}`} key={song.id}>
                <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4 hover:bg-gray-700 cursor-pointer">
                  <div className="w-12 h-12 bg-gray-600 rounded"></div>
                  <div>
                    <div className="font-medium">{song.title}</div>
                    <div className="text-sm text-gray-400">{song.artist}</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
      <div>
        <h2 className="text-2xl font-bold mb-4">Browse all</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredGenres.map((genre) => (
            <div
              key={genre}
              className="bg-gradient-to-br from-purple-700 to-blue-500 p-4 rounded-lg aspect-square flex items-end"
            >
              <span className="text-xl font-bold">{genre}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}


"use client"

import { useState, useEffect, useRef } from "react"
import { useParams } from "next/navigation"
import { Play, Pause, SkipBack, SkipForward, Download } from "lucide-react"
import { songs } from "@/lib/songs"
import Link from "next/link"

// This is the individual song page
// It displays song details and provides playback controls
export default function SongPage() {
  const { id } = useParams()
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)
  const song = songs.find((s) => s.id === id)

  useEffect(() => {
    const audio = audioRef.current
    if (audio) {
      const updateTime = () => setCurrentTime(audio.currentTime)
      audio.addEventListener("timeupdate", updateTime)
      return () => audio.removeEventListener("timeupdate", updateTime)
    }
  }, [])

  if (!song) return <div>Song not found</div>

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number.parseFloat(e.target.value)
    setCurrentTime(time)
    if (audioRef.current) {
      audioRef.current.currentTime = time
    }
  }

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const handleDownload = () => {
    // Redirect to download page
    window.location.href = "/download"
  }

  const currentIndex = songs.findIndex((s) => s.id === song.id)
  const previousSong = songs[(currentIndex - 1 + songs.length) % songs.length]
  const nextSong = songs[(currentIndex + 1) % songs.length]

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 sm:p-6">
      <div className="w-64 h-64 bg-gray-800 rounded-lg mb-6"></div>
      <h1 className="text-2xl sm:text-3xl font-bold mb-2">{song.title}</h1>
      <p className="text-lg sm:text-xl text-gray-400 mb-6">{song.artist}</p>
      <div className="w-full max-w-md mb-6">
        <audio
          ref={audioRef}
          src={song.location}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onLoadedMetadata={(e) => setDuration((e.target as HTMLAudioElement).duration)}
        />
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm">{formatTime(currentTime)}</span>
          <span className="text-sm">{formatTime(duration)}</span>
        </div>
        <input
          type="range"
          min={0}
          max={duration}
          value={currentTime}
          onChange={handleSeek}
          className="w-full h-1 bg-gray-600 rounded-full appearance-none cursor-pointer"
        />
      </div>
      <div className="flex space-x-4 mb-6">
        <Link href={`/song/${previousSong.id}`}>
          <button className="bg-gray-800 text-white rounded-full p-3 hover:bg-gray-700">
            <SkipBack size={24} />
          </button>
        </Link>
        <button onClick={togglePlay} className="bg-green-500 text-black rounded-full p-4 hover:bg-green-400">
          {isPlaying ? <Pause size={24} /> : <Play size={24} />}
        </button>
        <Link href={`/song/${nextSong.id}`}>
          <button className="bg-gray-800 text-white rounded-full p-3 hover:bg-gray-700">
            <SkipForward size={24} />
          </button>
        </Link>
      </div>
      <button
        onClick={handleDownload}
        className="bg-blue-500 text-white rounded-full px-6 py-2 hover:bg-blue-400 flex items-center"
      >
        <Download size={18} className="mr-2" />
        Download
      </button>
    </div>
  )
}


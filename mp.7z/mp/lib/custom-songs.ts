export interface CustomSong {
  id: string
  title: string
  artist: string
  album: string
  duration: string
  location: string
}

export const customSongs: CustomSong[] = [
  {
    id: "custom1",
    title: "My Custom Song",
    artist: "Local Artist",
    album: "Homemade Hits",
    duration: "3:45",
    location: "/path/to/my-custom-song.mp3",
  },
  {
    id: "custom2",
    title: "Another Original",
    artist: "Indie Performer",
    album: "Bedroom Recordings",
    duration: "4:12",
    location: "/path/to/another-original.mp3",
  },
]


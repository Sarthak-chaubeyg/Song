export interface Song {
  id: string
  title: string
  artist: string
  album: string
  duration: string
  location: string
}

export const songs: Song[] = [
  {
    id: "1",
    title: "Hymm for The Weakend",
    artist: "Queen",
    album: "A Night at the Opera",
    duration: "5:55",
    location: "hymm.mp3",
  },
  {
    id: "2",
    title: "Imagine",
    artist: "John Lennon",
    album: "Imagine",
    duration: "3:01",
    location: "/path/to/imagine.mp3",
  },
  {
    id: "3",
    title: "Billie Jean",
    artist: "Michael Jackson",
    album: "Thriller",
    duration: "4:54",
    location: "/path/to/billie-jean.mp3",
  },
  {
    id: "4",
    title: "Like a Rolling Stone",
    artist: "Bob Dylan",
    album: "Highway 61 Revisited",
    duration: "6:13",
    location: "/path/to/like-a-rolling-stone.mp3",
  },
  {
    id: "5",
    title: "Smells Like Teen Spirit",
    artist: "Nirvana",
    album: "Nevermind",
    duration: "5:01",
    location: "/path/to/smells-like-teen-spirit.mp3",
  },
  {
    id: "6",
    title: "Purple Rain",
    artist: "Prince",
    album: "Purple Rain",
    duration: "8:41",
    location: "/path/to/purple-rain.mp3",
  },
  {
    id: "7",
    title: "What's Going On",
    artist: "Marvin Gaye",
    album: "What's Going On",
    duration: "3:53",
    location: "/path/to/whats-going-on.mp3",
  },
  {
    id: "8",
    title: "Respect",
    artist: "Aretha Franklin",
    album: "I Never Loved a Man the Way I Love You",
    duration: "2:27",
    location: "/path/to/respect.mp3",
  },
]


"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react"
import { songs } from "@/lib/songs"
import Link from "next/link"

// This component represents the music player that appears at the top of every page
// It allows users to control playback, view song information, and navigate to the current song's page
export function Player() {
  const [currentSong, setCurrentSong] = useState(songs[0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    const audio = audioRef.current
    if (audio) {
      const updateTime = () => setCurrentTime(audio.currentTime)
      audio.addEventListener("timeupdate", updateTime)
      return () => audio.removeEventListener("timeupdate", updateTime)
    }
  }, [])

  // Function to toggle play/pause
  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  // Function to play the next song
  const playNextSong = () => {
    const currentIndex = songs.findIndex((song) => song.id === currentSong.id)
    const nextIndex = (currentIndex + 1) % songs.length
    setCurrentSong(songs[nextIndex])
    setIsPlaying(true)
  }

  // Function to play the previous song
  const playPreviousSong = () => {
    const currentIndex = songs.findIndex((song) => song.id === currentSong.id)
    const previousIndex = (currentIndex - 1 + songs.length) % songs.length
    setCurrentSong(songs[previousIndex])
    setIsPlaying(true)
  }

  // Function to handle seeking within the song
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number.parseFloat(e.target.value)
    setCurrentTime(time)
    if (audioRef.current) {
      audioRef.current.currentTime = time
    }
  }

  // Function to format time in minutes:seconds
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="bg-gray-900 border-b border-gray-800 p-2 sm:p-4">
      <audio
        ref={audioRef}
        src={currentSong.location}
        onEnded={playNextSong}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onLoadedMetadata={(e) => setDuration((e.target as HTMLAudioElement).duration)}
      />
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <Link href={`/song/${currentSong.id}`} className="flex items-center space-x-4 mb-2 sm:mb-0">
          <div className="w-10 h-10 sm:w-14 sm:h-14 bg-gray-800 rounded"></div>
          <div>
            <div className="font-medium text-sm sm:text-base">{currentSong.title}</div>
            <div className="text-xs sm:text-sm text-gray-400">{currentSong.artist}</div>
          </div>
        </Link>
        <div className="flex flex-col items-center w-full sm:w-1/2">
          <div className="flex items-center space-x-4 mb-2">
            <SkipBack
              className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 hover:text-white cursor-pointer"
              onClick={playPreviousSong}
            />
            <div
              className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full flex items-center justify-center hover:scale-105 cursor-pointer"
              onClick={togglePlay}
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 sm:w-5 sm:h-5 text-black" />
              ) : (
                <Play className="w-4 h-4 sm:w-5 sm:h-5 text-black" />
              )}
            </div>
            <SkipForward
              className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 hover:text-white cursor-pointer"
              onClick={playNextSong}
            />
          </div>
          <div className="w-full flex items-center space-x-2 text-xs">
            <span>{formatTime(currentTime)}</span>
            <input
              type="range"
              min={0}
              max={duration}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1 bg-gray-600 rounded-full appearance-none cursor-pointer"
            />
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        <div className="hidden sm:flex items-center space-x-2">
          <Volume2 className="w-5 h-5 text-gray-400" />
          <div className="w-24 h-1 bg-gray-600 rounded-full">
            <div className="w-16 h-1 bg-white rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  )
}


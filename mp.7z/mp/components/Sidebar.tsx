import Link from "next/link"
import { Home, Search, Library, Plus, Heart } from "lucide-react"

const playlists = ["Chill Vibes", "Workout Mix", "Study Session", "Party Anthems", "Road Trip"]

export function Sidebar() {
  return (
    <div className="w-64 bg-black p-6 hidden md:block">
      <nav className="space-y-4 mb-6">
        <Link href="/" className="flex items-center space-x-2 text-white hover:text-green-500">
          <Home />
          <span>Home</span>
        </Link>
        <Link href="/search" className="flex items-center space-x-2 text-white hover:text-green-500">
          <Search />
          <span>Search</span>
        </Link>
        <Link href="/library" className="flex items-center space-x-2 text-white hover:text-green-500">
          <Library />
          <span>Your Library</span>
        </Link>
      </nav>
      <div className="mt-6 space-y-4">
        <button className="flex items-center space-x-2 text-white hover:text-green-500">
          <Plus className="p-1 bg-gray-800 rounded-sm" />
          <span>Create Playlist</span>
        </button>
        <button className="flex items-center space-x-2 text-white hover:text-green-500">
          <Heart className="p-1 bg-gradient-to-br from-purple-700 to-blue-500 rounded-sm" />
          <span>Liked Songs</span>
        </button>
      </div>
      <div className="mt-6">
        <h2 className="text-sm font-semibold text-gray-400 mb-2">PLAYLISTS</h2>
        <ul className="space-y-2">
          {playlists.map((playlist, index) => (
            <li key={index}>
              <Link href={`/playlist/${index}`} className="text-gray-300 hover:text-white">
                {playlist}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

